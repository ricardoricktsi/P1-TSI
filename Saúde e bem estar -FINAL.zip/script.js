/*Animação do Modal de cadastro*/
function Modal(modalID){
    const modal = document.getElementById(modalID);
    modal.classList.add('mostrar')

    modal.addEventListener('click', function(e){
        if(e.target.id == modalID || e.target.className == 'close'){
            modal.classList.remove('mostrar')
        }else if(e.target.className === 'login'){
            modal.classList.remove('mostrar')
        }
    })
}

$('#fale').click(function(e) {
    e.preventDefault()
    Modal('modal-contato')
})



